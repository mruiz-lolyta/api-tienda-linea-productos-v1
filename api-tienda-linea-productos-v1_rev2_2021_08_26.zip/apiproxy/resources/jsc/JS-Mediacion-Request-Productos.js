var request_verb = context.getVariable('request.verb');
var proxy_pathsuffix = context.getVariable('proxy.pathsuffix');
var request_content = JSON.parse(context.getVariable('request.content'));

var jsonRequest;

    try {
        context.setVariable('message.header.Content-Type', 'application/json');
        jsonRequest = {
            "title": request_content.nombre,
            "price": request_content.precio,
            "description": request_content.descripcion,
            "category": request_content.categoria,
            "image": request_content.urlImagen
        }
        context.setVariable('request.content', JSON.stringify(jsonRequest));           
    } catch (err) { }
