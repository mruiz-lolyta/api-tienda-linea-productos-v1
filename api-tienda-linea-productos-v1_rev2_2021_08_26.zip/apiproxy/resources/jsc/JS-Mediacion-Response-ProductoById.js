var message_content = context.getVariable('message.content');
var json_content;

context.setVariable('message.header.Content-Type', 'application/json');

try {

    json_content = JSON.parse(message_content);

    var apigeeResp = new ApigeeResponse(); 
    apigeeResp.resultado.id = json_content.id;
    apigeeResp.resultado.nombre = json_content.title;
    apigeeResp.resultado.precio = json_content.price;
    apigeeResp.resultado.descripcion = json_content.description;
    apigeeResp.resultado.categoria = json_content.category;
    apigeeResp.resultado.urlImagen = json_content.image;

    body_response = {
        "mensaje": "Operación exitosa.",
        "resultado": apigeeResp.resultado
    }

    context.setVariable('message.reason.phrase', 'OK');
    context.setVariable('message.status.code', "200");
    context.setVariable("response.content", JSON.stringify(body_response));

} catch (err) {
    print("error: " + err.message);
}

function ApigeeResponse() {
    this.mensaje;
    this.resultado = new Resultado();
    function Resultado() {
        this.id;
        this.nombre;
        this.precio;
        this.descripcion;
        this.categoria;
        this.urlImagen;
    }
}